# AI QA Engineering Platform- TestFlair — Master Build Prompt

You are a senior staff software architect, AI engineer, Playwright automation architect, security engineer, and product designer.

I want you to design and build a professional-grade **AI-powered QA Engineering Platform** for my QA/engineering team.

This is NOT intended to be a simple AI test-case generator.

The product should behave like an:

> **AI QA Engineer + Playwright Automation Platform + Test Intelligence Platform + Flaky Test Analyzer + Bitbucket/Git Agent**

The initial implementation will be used internally, but the product should be designed and presented at the quality level of a **global enterprise SaaS product**.

The UI, UX, architecture, security model, and workflows should feel like a serious product that could eventually be offered to enterprise customers.

Think about the product quality bar of products such as Linear, Sentry, Datadog, GitHub, Vercel, and modern developer/observability platforms.

Do NOT copy their design. Create an original design system with a similar level of polish.

---

# 1. PRODUCT VISION

The platform should allow a QA engineer to:

1. Connect to a Bitbucket repository.
2. Select a specific branch.
3. Checkout that branch into an isolated workspace.
4. Analyze the existing Playwright framework.
5. Understand existing tests, page objects, fixtures, utilities, and conventions.
6. Provide a requirement/user story.
7. Generate test scenarios.
8. Review and approve scenarios.
9. Generate Playwright tests following the existing framework architecture.
10. Run those tests against the selected branch/environment.
11. Analyze failures.
12. Detect flaky tests.
13. Suggest test fixes/healing.
14. Show git diffs.
15. Allow the user to approve changes.
16. Commit changes.
17. Optionally create a Bitbucket pull request.

The complete workflow should feel like:

```text
Requirement
     ↓
AI Test Design
     ↓
Test Case Review
     ↓
Playwright Test Generation
     ↓
Code Review / Diff
     ↓
Branch Execution
     ↓
Test Results
     ↓
Failure Analysis
     ↓
Flaky Test Intelligence
     ↓
AI Healing Suggestion
     ↓
Human Approval
     ↓
Commit
     ↓
Pull Request
```

---

# 2. EXISTING ENVIRONMENT

Assume:

* Automation framework: Playwright
* Existing Playwright framework already exists
* Source control: Bitbucket
* Multiple repositories may exist
* Multiple branches exist
* Azure OpenAI access is already available
* We want to use Azure OpenAI
* The existing Playwright framework is the source of truth
* We do NOT want to replace the existing automation framework

The system must integrate with the existing project instead of forcing a new framework.

---

# 3. CORE PRODUCT PRINCIPLE

The product is NOT:

> "Give AI the DOM and ask it to write Selenium/Playwright code."

Instead, it should be:

> **An AI QA engineering layer that understands an existing Playwright framework, repository, branch, application structure, test history, and execution evidence.**

The AI should use the organization's existing patterns.

For example, if the repository already has:

```text
Page Objects
Fixtures
Components
Custom Assertions
Test Data Factories
Authentication Fixtures
API Helpers
Utilities
```

the generated tests must use those abstractions.

Prefer:

```typescript
await checkoutPage.completeCheckout(order);
```

over:

```typescript
await page.locator('#checkout').click();
```

if the existing framework already provides `completeCheckout()`.

---

# 4. BITBUCKET INTEGRATION

Bitbucket integration is a core feature.

The user should be able to:

* Connect Bitbucket
* Select workspace
* Browse repositories
* Search repositories
* View branches
* Search/filter branches
* Select branch
* View latest commit
* Checkout branch
* Analyze branch
* Execute Playwright tests on branch
* View git status
* View git diff
* Commit generated changes
* Create pull request

Example:

```text
Repository:
customer-portal

Branch:
feature/checkout-redesign

Commit:
a91f83c
```

The selected branch must remain part of the execution and AI context.

The AI must NEVER silently assume `main`.

---

# 5. BRANCH-FIRST ARCHITECTURE

Branch context is extremely important.

A test generated against:

```text
main
```

may be completely different from a test generated against:

```text
feature/new-checkout
```

Therefore every relevant operation should know:

```text
Repository
+
Branch
+
Commit SHA
+
Environment
```

Use immutable commit SHA internally where possible so that an execution can always be reproduced.

Example:

```json
{
  "repository": "customer-portal",
  "branch": "feature/checkout-redesign",
  "commitSha": "a91f83c",
  "environment": "QA"
}
```

---

# 6. SECURE REPOSITORY WORKSPACES

Do not checkout and execute arbitrary repository code directly on the main application server.

Create an isolated execution/workspace abstraction.

Preferred conceptual architecture:

```text
Bitbucket
   ↓
Repository Manager
   ↓
Ephemeral Workspace
   ↓
Checkout branch
   ↓
Analyze repository
   ↓
Run Playwright
   ↓
Collect artifacts
   ↓
Destroy workspace
```

Consider Docker/containerized execution or another secure sandbox.

The design must consider:

* arbitrary shell commands
* malicious repository code
* dependency installation
* npm lifecycle scripts
* secrets
* environment variables
* filesystem access
* network access
* CPU limits
* memory limits
* execution timeout
* process isolation
* cleanup

Do not blindly execute arbitrary repository commands without an execution policy.

---

# 7. PLAYWRIGHT FRAMEWORK DISCOVERY

When a repository is connected, automatically analyze the Playwright framework.

Discover:

```text
package.json
playwright.config.*
tests/
pages/
fixtures/
components/
utils/
helpers/
test-data/
auth/
setup/
```

Also detect:

* Playwright version
* browser projects
* test projects
* tags
* fixtures
* retries
* workers
* global setup
* storageState
* authentication strategy
* custom reporters
* test conventions

Generate a repository profile.

Example:

```text
Playwright Framework

Version: 1.x

Projects:
Chrome
Firefox
WebKit

Authentication:
storageState + auth fixture

Page Objects:
Yes

Custom Fixtures:
Yes

Test Data Factory:
Yes

Custom Assertions:
Yes
```

---

# 8. REPOSITORY CODE INTELLIGENCE

Do NOT send the entire repository to Azure OpenAI.

Build a repository indexing/retrieval layer.

The system should understand:

* files
* classes
* functions
* imports
* page objects
* fixtures
* tests
* components
* utilities
* API helpers
* test data
* configuration

Use retrieval to provide only relevant context to each AI task.

For example, for a login test, retrieve:

```text
LoginPage
AuthFixture
Existing Login Tests
Test Data
Relevant Playwright Config
Relevant Utilities
Framework Conventions
```

Do not provide unrelated repository files.

---

# 9. DOM / DATA LEAKAGE PROTECTION

This is one of the highest-priority requirements.

Our manager is concerned about sending application DOM to AI because it may contain:

* PII
* customer information
* internal business data
* tokens
* secrets
* financial data
* account information
* sensitive application content

Therefore:

# NEVER SEND RAW DOM TO AZURE OPENAI BY DEFAULT.

Build a local/browser-side **DOM Context Sanitizer**.

Architecture:

```text
Browser
   ↓
DOM Extractor
   ↓
Sanitizer
   ↓
PII Detection
   ↓
Secret Detection
   ↓
Semantic Page Model
   ↓
Azure OpenAI
```

The AI should receive a structured representation of the page.

Example:

Instead of:

```html
<input
  id="customer-ssn"
  value="123-45-6789"
  data-user-id="839292"
/>
```

send:

```json
{
  "element": "input",
  "role": "textbox",
  "label": "SSN",
  "type": "text",
  "required": true,
  "visible": true,
  "testId": "customer-ssn"
}
```

---

# 10. DOM SANITIZATION RULES

By default remove/redact:

* input values
* PII
* email addresses
* phone numbers
* addresses
* financial information
* authentication tokens
* cookies
* authorization headers
* localStorage
* sessionStorage
* secrets
* hidden sensitive fields
* network payloads
* environment variables

Create an allowlist-based model.

Example:

```yaml
ai_security:
  send_raw_dom: false

  sanitize:
    input_values: true
    text_content: true
    hidden_elements: true
    cookies: true
    local_storage: true
    session_storage: true
    authorization_headers: true
    network_payloads: true

  pii_detection: true
  secret_detection: true
```

The policy must be configurable.

---

# 11. AI CONTEXT TRANSPARENCY

Every AI operation should show what context was used.

Example:

```text
AI Context

Repository:
customer-portal

Branch:
feature/checkout-redesign

Context used:

✓ CheckoutPage.ts
✓ checkout.spec.ts
✓ auth.fixture.ts
✓ playwright.config.ts
✓ Sanitized page model

Excluded:

✓ Customer data
✓ Input values
✓ Cookies
✓ Authorization headers
✓ Secrets
```

Also show:

```text
DOM Security

Elements discovered: 142
Elements sent: 97
Redacted: 32
Blocked: 13

PII detected: 8
Secrets detected: 0
```

This is important for enterprise trust.

---

# 12. CREDENTIAL MANAGEMENT

UI automation requires authentication.

Credentials are a first-class part of the product.

However:

# THE AI MUST NEVER RECEIVE ACTUAL CREDENTIAL VALUES.

The user may provide credentials through the UI when required.

For MVP, we do NOT have access to a vault/secret-management system.

Therefore do NOT require Azure Key Vault or another vault.

Use a **runtime credential model**.

---

# 13. RUNTIME CREDENTIAL FLOW

Example:

```text
User selects:

Repository
Branch
Environment
Credential
        ↓
Secure Credential Input
        ↓
Execution Worker
        ↓
Playwright
        ↓
Application
        ↓
Execution finishes
        ↓
Credential discarded
```

Credentials should preferably exist only in memory for the duration of the execution.

Do not persist plaintext credentials in PostgreSQL.

Do not send credentials to Azure OpenAI.

Do not include credentials in:

* AI prompts
* AI responses
* logs
* screenshots
* traces where avoidable
* git commits
* generated source code
* audit logs

---

# 14. CREDENTIAL UI

Provide:

```text
Test Configuration

Repository
[ customer-portal ]

Branch
[ feature/checkout-redesign ]

Environment
[ QA ]

Authentication
○ None
○ Existing Framework Auth
● Runtime Credential

Credential
[ checkout_qa_user ]
```

If runtime credential is selected:

```text
Username
[........................]

Password
[••••••••••••••••••••••]
```

The application should never display the password again after submission.

---

# 15. EXISTING PLAYWRIGHT AUTHENTICATION

Before asking for credentials, inspect the existing framework.

Look for:

```text
auth.setup.ts
storageState
loginFixture
authenticatedPage
testUser
createAuthenticatedContext()
```

If the existing framework already provides authentication, use it.

For example:

```typescript
test('checkout', async ({ authenticatedPage }) => {
   ...
});
```

is preferred over generating a new login flow.

Important rule:

> Never reinvent authentication when the existing Playwright framework already provides it.

---

# 16. CREDENTIAL ALIAS

The AI may know a credential alias but never the actual value.

Example:

```json
{
  "authenticationRequired": true,
  "credentialAlias": "checkout_qa_user",
  "usernameAvailable": true,
  "passwordAvailable": true,
  "secretValuesVisibleToAI": false
}
```

The generated code may reference the framework/runtime abstraction:

```typescript
await loginPage.login(
  credentials.checkoutQaUser.username,
  credentials.checkoutQaUser.password
);
```

The actual values are injected only during execution.

---

# 17. AI TEST DESIGNER

The user should be able to provide:

* Jira story
* requirement
* acceptance criteria
* plain text
* markdown
* document
* ticket reference

AI should generate test scenarios.

Example:

```text
Scenario:
Valid Checkout

Priority:
High

Risk:
High

Preconditions:
Authenticated customer

Steps:
1. Add product to cart
2. Navigate to checkout
3. Enter valid payment details
4. Submit order

Expected:
Order confirmation displayed
```

Generate edge cases such as:

* invalid input
* empty input
* duplicate submission
* timeout
* network failure
* session expiration
* permission issues
* boundary values
* concurrency
* invalid state

The user must be able to:

* approve
* reject
* edit
* regenerate

---

# 18. AI PLAYWRIGHT TEST GENERATOR

After test scenario approval, generate Playwright code.

The generator must follow repository conventions.

Use:

* existing page objects
* fixtures
* components
* utilities
* test data factories
* assertions
* authentication mechanisms

Do not generate raw locators when reusable abstractions already exist.

Output should include:

* file path
* generated code
* explanation
* dependencies
* framework components used

---

# 19. CODE REVIEW / DIFF

Never directly overwrite existing tests.

Show a diff:

```diff
+ test('should complete checkout', async ({ checkoutPage }) => {
+   await checkoutPage.open();
+   await checkoutPage.completeCheckout(testOrder);
+ });
```

The user should be able to:

* approve
* reject
* edit
* regenerate

Only after approval should changes be applied.

---

# 20. TEST EXECUTION

Provide a professional test execution interface.

User can run:

* entire suite
* selected tests
* test file
* tag
* project
* browser
* failed tests
* impacted tests
* flaky tests

Configuration:

```text
Repository
Branch
Commit
Environment
Browser
Project
Workers
Retries
Tags
Credential
Tests
```

---

# 21. LIVE EXECUTION UI

Example:

```text
Execution #4821

Repository:
customer-portal

Branch:
feature/checkout-redesign

Commit:
a91f83c

Progress
━━━━━━━━━━━━━━━━━━░░░░

Passed       184
Failed         7
Flaky         12
Running       15
Skipped        3
```

Click a test to show:

* status
* duration
* logs
* screenshot
* trace
* video
* console
* network failures
* AI analysis
* previous history
* source code
* git changes

---

# 22. FAILURE ANALYSIS AGENT

When a Playwright test fails, collect:

* test name
* error
* stack trace
* screenshot
* trace
* video if available
* console logs
* network errors
* duration
* browser
* OS
* branch
* commit SHA
* historical results

AI should classify:

```text
PRODUCT BUG
TEST BUG
FLAKY TEST
TEST DATA ISSUE
ENVIRONMENT ISSUE
NETWORK ISSUE
INFRASTRUCTURE ISSUE
UNKNOWN
```

Provide:

```text
Root Cause Hypothesis
Confidence
Evidence
Recommended Action
```

---

# 23. FLAKY TEST ANALYZER

Build a dedicated flaky test intelligence system.

Analyze historical execution data.

For every test calculate:

```text
Flakiness Score
Pass Rate
Failure Rate
Average Duration
Duration Variance
Recent Failure Rate
Consecutive Failures
Failure Pattern
```

Detect:

* race conditions
* timing issues
* hard waits
* unstable selectors
* environment dependency
* network dependency
* test data collisions
* order dependency
* shared state
* asynchronous UI behavior

Example:

```text
FLAKY TEST

checkout.spec.ts
should create an order

Flakiness Score:
87/100

Likely Cause:
Race condition

Evidence:
7 of last 10 failures occurred during
cart-to-checkout transition.

Recommendation:
Replace fixed timeout with synchronization.
```

---

# 24. FLAKY TEST DASHBOARD

Create a dedicated dashboard.

Show:

* Top flaky tests
* Flakiness trend
* New flaky tests
* Most unstable suites
* Flaky tests by branch
* Flaky tests by browser
* Flaky tests by environment
* Failure reason distribution
* Tests repeatedly failing at the same step
* Average retry count

Allow drill-down.

---

# 25. TEST HEALING AGENT

When a test fails because of a changed UI/locator:

AI should analyze:

* existing test
* current semantic page model
* screenshot
* trace
* git diff
* previous successful execution
* relevant page object

Then suggest a patch.

Example:

```diff
- page.getByTestId('submit-order')
+ page.getByRole('button', { name: 'Submit Order' })
```

The system must:

1. Propose fix.
2. Show diff.
3. Require user approval.
4. Apply fix.
5. Run test.
6. Verify result.
7. Allow commit.

Never silently modify tests.

---

# 26. GIT DIFF INTELLIGENCE

Analyze changes between branches/commits.

Example:

```text
main
 ↓
feature/checkout-redesign
```

Identify:

* changed files
* changed components
* changed page objects
* changed APIs
* changed tests

Then determine:

```text
Potentially Impacted Tests: 23

High Risk: 7

Potentially Obsolete: 3

Recommended New Tests: 5
```

---

# 27. TEST IMPACT ANALYSIS

Given:

```text
CheckoutService.ts changed
```

identify potentially impacted:

```text
Checkout Tests
Payment Tests
Order Tests
Cart Tests
```

Use:

* imports
* repository relationships
* test metadata
* historical execution data
* git history
* AI reasoning

---

# 28. BRANCH INTELLIGENCE

Every branch should have a dedicated dashboard.

Example:

```text
feature/checkout-redesign

Repository:
customer-portal

Commit:
a91f83c

Tests
────────────

Passed       382
Failed        11
Flaky         17

AI Analysis
────────────

Potential Regressions: 4
New Failures: 6
Potential Flaky Tests: 3

Changed Areas
────────────

Checkout
Payment
Order Summary
```

---

# 29. EXECUTIVE DASHBOARD

Create a beautiful executive dashboard.

Show:

* total tests
* execution count
* pass rate
* failure rate
* flaky tests
* automation coverage
* test coverage
* newly failing tests
* test execution trend
* average duration
* slowest tests
* recent AI-generated tests
* recently healed tests
* branch activity
* QA risk score
* AI activity

Charts should be polished and interactive.

---

# 30. QA INTELLIGENCE DASHBOARD

Provide:

* stable tests
* flaky tests
* failing tests
* skipped tests
* slow tests
* recently changed tests
* tests affected by code changes
* high-risk areas

Filters:

* repository
* branch
* project
* suite
* owner
* browser
* environment
* status
* time range

---

# 31. MAIN APPLICATION NAVIGATION

Design a professional information architecture.

Suggested:

```text
Overview

AI QA
  ├── Test Designer
  ├── Test Generator
  ├── Failure Analyzer
  └── Test Healer

Tests
  ├── Test Explorer
  ├── Executions
  ├── Flaky Tests
  └── Test Impact

Repositories
  ├── Repositories
  ├── Branches
  └── Code Intelligence

Insights
  ├── QA Intelligence
  ├── Coverage
  ├── Trends
  └── AI Insights

Integrations
  ├── Bitbucket
  ├── Jira
  └── Azure OpenAI

Settings
  ├── Workspace
  ├── AI
  ├── Security
  ├── Credentials
  └── Execution
```

Improve this if you identify a better product architecture.

---

# 32. UI/UX QUALITY BAR

The UI is extremely important.

It must feel like a global enterprise SaaS product.

Requirements:

* polished typography
* strong visual hierarchy
* excellent spacing
* professional color system
* light/dark mode
* responsive layout
* subtle animations
* keyboard shortcuts where appropriate
* command palette
* professional charts
* excellent tables
* search
* filters
* pagination
* drill-down experiences
* meaningful empty states
* skeleton loaders
* proper error states
* accessible controls
* consistent status colors
* reusable design system

Avoid:

* generic Bootstrap-looking dashboards
* excessive gradients
* excessive glassmorphism
* cartoonish AI graphics
* huge rounded cards everywhere
* unnecessary animations
* fake metrics

The UI should look credible in a leadership presentation.

---

# 33. AI ACTIVITY / EXPLAINABILITY

Every AI operation should be explainable.

Example:

```text
AI Test Generation

Repository:
customer-portal

Branch:
feature/checkout-redesign

Context:

✓ CheckoutPage.ts
✓ checkout.spec.ts
✓ auth.fixture.ts
✓ playwright.config.ts
✓ Semantic Page Model

Security:

✓ 32 values redacted
✓ 8 PII items detected
✓ 0 secrets exposed

Model:
Azure OpenAI / <deployment>

Result:
3 test cases generated
```

---

# 34. AZURE OPENAI

Use Azure OpenAI.

Never hardcode credentials.

Use environment variables/configuration.

Support:

* endpoint
* deployment
* API version
* timeout
* retries
* token limits
* temperature

Create a provider abstraction:

```text
AIService
   |
   +── AzureOpenAIProvider
   |
   +── FutureProvider
```

This keeps the architecture extensible.

---

# 35. AI AGENT ARCHITECTURE

Do NOT create one giant AI prompt.

Create specialized agents/services:

```text
QA Orchestrator
       |
       +── Requirement Analyst
       |
       +── Repository Analyst
       |
       +── Test Designer
       |
       +── Playwright Generator
       |
       +── Failure Analyzer
       |
       +── Flaky Test Analyzer
       |
       +── Test Healer
       |
       +── Test Reviewer
```

The orchestrator should control workflow and permissions.

---

# 36. AI OUTPUT VALIDATION

Prefer structured outputs.

Example:

```json
{
  "testCases": [
    {
      "title": "Valid checkout",
      "priority": "HIGH",
      "steps": [],
      "expectedResults": []
    }
  ]
}
```

Validate AI output against schemas.

Never blindly execute arbitrary AI-generated commands.

---

# 37. AI SAFETY

AI must NEVER:

* retrieve passwords
* expose secrets
* request credentials unnecessarily
* execute destructive commands without approval
* modify unrelated files
* push directly to protected branches
* merge pull requests automatically
* disable security controls
* bypass repository permissions

Potentially destructive actions must follow:

```text
AI proposes
   ↓
Human approves
   ↓
System executes
```

---

# 38. CREDENTIAL SECURITY

Strict rules:

1. Never send passwords to Azure OpenAI.
2. Never put secrets in AI prompts.
3. Never put secrets in AI responses.
4. Never log secrets.
5. Never store plaintext credentials in PostgreSQL.
6. Never expose credentials through API responses.
7. Never commit credentials to Git.
8. Never include credentials in generated source code.
9. Redact secrets from logs.
10. Redact secrets from network artifacts where possible.
11. Destroy runtime credentials after execution.
12. Do not expose credential values to AI agents.

---

# 39. AUDIT LOG

Record:

```text
Repository connected
Branch selected
Branch checked out
AI test generated
AI context accessed
Sensitive data redacted
Test executed
Failure analyzed
Test healed
Commit created
Pull request created
Credential used
```

Each event should include:

* user
* timestamp
* repository
* branch
* action
* result

Never store secret values.

---

# 40. DATA MODEL

Design a proper relational model.

Potential entities:

```text
User
Workspace
Project
Repository
Branch
Commit
Environment
Credential
Test
TestSuite
TestExecution
TestResult
Failure
FlakyAnalysis
GeneratedTest
TestChange
PullRequest
Artifact
AgentRun
AIRequest
AIResponse
AuditLog
SecurityEvent
```

Credential should contain metadata/reference only, not plaintext secret values.

Support multi-project architecture.

Design so multi-tenancy can be added later if appropriate.

---

# 41. API ARCHITECTURE

Create clean APIs.

Examples:

```text
GET    /api/repositories
GET    /api/repositories/:id/branches
POST   /api/workspaces/checkout

POST   /api/ai/test-design
POST   /api/ai/test-generation
POST   /api/ai/failure-analysis
POST   /api/ai/flaky-analysis
POST   /api/ai/test-healing

POST   /api/tests/:id/run
GET    /api/tests/:id/history

GET    /api/executions/:id
GET    /api/branches/:id/impact

POST   /api/git/commit
POST   /api/git/pull-request

POST   /api/credentials/runtime
```

Keep AI orchestration separate from normal CRUD operations.

---

# 42. TECHNOLOGY

Unless there is a strong architectural reason otherwise, consider:

Frontend:

* React
* TypeScript
* Next.js
* Tailwind CSS
* high-quality component library
* Recharts/ECharts or equivalent

Backend:

* TypeScript/Node.js or Python

Database:

* PostgreSQL

AI:

* Azure OpenAI

Automation:

* Playwright

Source Control:

* Git
* Bitbucket API

Execution:

* Docker/containerized workers where appropriate

Infrastructure:

* Redis/queue where useful
* structured logging
* metrics
* tracing

Choose alternatives if there is a strong reason, but explain the tradeoff.

---

# 43. DEVELOPMENT PHILOSOPHY

Do not build a fake UI with hardcoded data everywhere.

Implement real foundations.

Where an integration is unavailable during development, create:

```text
Interface
+
Realistic Mock Adapter
```

For example:

```text
BitbucketProvider
   ├── BitbucketImplementation
   └── MockBitbucketProvider
```

Use seeded data only for demo mode.

Do not hardcode fake metrics into production logic.

---

# 44. DEMO MODE

Create a realistic demo mode.

It should include:

* sample repository
* multiple branches
* realistic Playwright tests
* test executions
* failures
* flaky tests
* AI insights
* git changes
* branch intelligence
* dashboards

Demo mode should allow the product to be presented without connecting a real repository.

---

# 45. ONBOARDING FLOW

Create a professional onboarding experience.

Example:

```text
Welcome
   ↓
Create Workspace
   ↓
Connect Bitbucket
   ↓
Select Repository
   ↓
Select Branch
   ↓
Detect Playwright Framework
   ↓
Configure Environment
   ↓
Configure Authentication
   ↓
Configure Azure OpenAI
   ↓
Run First Test
   ↓
Generate First AI Test
```

Make onboarding feel polished and simple.

---

# 46. PRIMARY USER JOURNEY

The most important workflow should be:

## Step 1

Select repository.

## Step 2

Select branch.

## Step 3

Select environment.

## Step 4

Select authentication method.

## Step 5

Provide requirement.

## Step 6

AI analyzes repository.

## Step 7

AI generates test scenarios.

## Step 8

User reviews scenarios.

## Step 9

AI generates Playwright test.

## Step 10

Show code diff.

## Step 11

User approves.

## Step 12

Run test.

## Step 13

Show execution.

## Step 14

If failure occurs, AI analyzes failure.

## Step 15

AI suggests fix.

## Step 16

User approves fix.

## Step 17

Run test again.

## Step 18

Commit.

## Step 19

Create pull request.

This should be the flagship experience.

---

# 47. PRODUCT PHILOSOPHY

The system should augment QA engineers rather than blindly replace them.

The philosophy is:

```text
AI proposes
Human reviews
System executes
Evidence validates
```

AI should be highly capable but controlled.

---

# 48. PHASED IMPLEMENTATION

## Phase 1 — Foundation

Build:

* application shell
* design system
* dashboard
* project/workspace model
* Bitbucket integration
* repository browser
* branch browser
* branch checkout abstraction
* isolated workspace abstraction
* PostgreSQL schema
* Azure OpenAI provider
* Playwright project discovery

## Phase 2 — AI QA

Build:

* repository indexing
* context retrieval
* DOM sanitizer
* requirement analyzer
* test designer
* Playwright generator
* code diff/review

## Phase 3 — Execution Intelligence

Build:

* Playwright execution workers
* execution UI
* result ingestion
* screenshots
* traces
* failure analyzer
* flaky test analyzer

## Phase 4 — Engineering Agent

Build:

* test healing
* test impact analysis
* git diff intelligence
* commit
* pull request creation
* branch intelligence

## Phase 5 — Enterprise

Build:

* RBAC
* audit logs
* security policies
* advanced analytics
* observability
* multi-project
* multi-tenant readiness

---

# 49. WHAT I WANT YOU TO DO FIRST

Do NOT immediately generate hundreds of UI files.

First analyze the entire product requirement.

Then provide:

1. System architecture
2. Component architecture
3. Repository/workspace architecture
4. Bitbucket integration architecture
5. Playwright execution architecture
6. AI agent architecture
7. DOM sanitization architecture
8. Credential/runtime secret architecture
9. Database schema
10. API contracts
11. Frontend information architecture
12. Design system
13. Security threat model
14. Data flow diagrams
15. MVP scope
16. Phase 2 scope
17. Phase 3 scope
18. Technical risks
19. Recommended technology stack
20. Development plan

Then begin implementation incrementally.

---

# 50. IMPORTANT ARCHITECTURAL SEPARATION

Maintain strict separation between:

```text
AI Layer
```

and:

```text
Execution Layer
```

The AI may reason about:

```text
Repository
Branch
Framework
Test
Semantic Page Model
Failure Evidence
Credential Alias
```

But it must NOT directly access:

```text
Password
Secret
Cookie
Authorization Token
Sensitive DOM Value
Production Credential
```

Execution workers handle:

```text
Credentials
Browser
Application
Test execution
Artifacts
```

This separation is one of the most important security principles of the system.

---

# 51. FINAL PRODUCT GOAL

The final product should feel like:

> **An AI QA Engineer that understands my Playwright framework, works against my actual Bitbucket branches, securely executes tests, analyzes failures, identifies flaky tests, suggests fixes, and helps create production-quality test changes.**

It should combine:

```text
Bitbucket
     +
Playwright
     +
AI
     +
Test Intelligence
     +
Flaky Test Analysis
     +
Failure Analysis
     +
Test Healing
     +
Enterprise Security
     +
Professional SaaS UX
```

The application should be polished enough to demonstrate to:

* QA leadership
* Engineering leadership
* Architects
* Security teams
* Developers
* Product teams

Do not optimize only for a visually impressive prototype.

Build the foundations so the product can genuinely evolve into a production-grade platform.
