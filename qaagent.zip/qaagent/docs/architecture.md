# TestFlair architecture

## Product boundary

TestFlair is a control plane for QA work, not an execution host for arbitrary repository code. It maintains immutable repository/branch/commit/environment context, proposes changes, records approvals, and delegates approved work to isolated workers. AI is a bounded advisory layer: it receives retrieved source context and sanitized evidence, never runtime secrets or raw customer data.

## System architecture

```text
Web application (Next.js) ──> Control-plane API ──> PostgreSQL
          │                         │                  │
          │                         ├─> Redis queue     └─> audit/event store
          │                         ├─> Bitbucket provider
          │                         └─> Azure OpenAI provider
          │                                              
          └─ live updates <── worker event stream <── isolated execution worker
                                                    ├─ ephemeral checkout
                                                    ├─ policy-enforced Playwright
                                                    └─ encrypted artifact store
```

The control plane is intentionally unable to run repository commands. Workers have short-lived scoped credentials, an allowlisted network policy, read-only base image, CPU/memory/time quotas, artifact redaction, and guaranteed teardown.

## Component architecture

`apps/web` hosts the UI/BFF. `apps/api` owns CRUD, approval workflows, and event ingestion. `apps/worker` consumes immutable execution jobs. Shared packages contain domain contracts, schema validation, policy evaluation, providers, repository intelligence, and UI primitives. Each external service is accessed through an interface with a demo adapter and a production adapter.

Key services:

* Repository manager: Bitbucket metadata, commits, checkouts, diffs.
* Framework discovery/indexer: profile, symbols, imports, conventions, embeddings/retrieval.
* QA orchestrator: coordinates specialized structured-output agents.
* Execution broker: turns approved runs into constrained worker jobs.
* Evidence intelligence: results, failures, flakiness, impact and healing proposals.
* Security service: redaction, policy evaluation, secret scanning, audit events.

## Repository and workspace architecture

A `RepositoryRef` is always `{repositoryId, branchName, commitSha, environmentId}`. Branch names are UI choices; commit SHA is the execution identity. Workers clone at an exact SHA into a one-job workspace, perform discovery or permitted Playwright commands, upload scrubbed artifacts, and destroy the workspace. Generated edits remain patches until an explicit `ChangeApproval` is recorded; commits and PRs use least-privilege Bitbucket tokens and cannot target protected branches without policy approval.

## Bitbucket integration

`BitbucketProvider` supports workspace/repository/branch discovery, commit lookup, diff, commit, and PR creation. The production adapter uses OAuth/app-password credentials stored outside application records; the demo adapter serves seeded repositories only. A checkout request binds the resolved SHA before queueing. Every Bitbucket action emits an audit event and is authorization-checked.

## Playwright execution

Workers execute a pre-approved command template, never AI-provided shell. They first inspect `package.json`, Playwright config, fixtures, auth setup, projects and reporters. Dependency installation is policy-gated (lockfile required; lifecycle scripts disabled unless allowlisted). Runtime credentials are injected only into worker memory/environment and redacted from console, trace, screenshots and uploaded artifacts. Results are normalized to test/run/artifact records and streamed to the UI.

## AI agents

The QA orchestrator calls narrowly scoped agents with JSON-schema outputs: requirement analyst, repository analyst, test designer, Playwright generator, failure analyzer, flaky analyzer, healer and reviewer. Retrieval selects relevant source symbols and existing patterns. The orchestrator validates output, stores an explainability record (model, context file hashes, policy/redaction summary), and creates proposals—not commands or direct source mutations.

## DOM sanitization

Browser-side extraction builds an allowlist-based semantic page model (role, accessible name, label, element type, state, visibility, test id). It excludes raw HTML, input values, hidden content, cookies, storage, authorization headers and network payloads by default. A local detector redacts PII and secret patterns before any provider call. The security record reports discovered/sent/redacted/blocked counts and may fail closed when policy detects sensitive data.

## Runtime credentials

Credential records are metadata only: alias, environment, owner, rotation status and allowed repositories. A one-time secure submission creates an in-memory encrypted job payload routed directly to the worker; it is neither persisted in PostgreSQL nor exposed by API/UI/AI/audit logs. Existing framework authentication is detected and preferred. Values are disposed when the execution ends or expires.

## Core data model

Tenant-ready tables use `workspace_id` scoping: `users`, `workspaces`, `projects`, `repositories`, `branches`, `commits`, `environments`, `credential_metadata`, `repository_profiles`, `source_documents`, `source_symbols`, `tests`, `test_suites`, `executions`, `test_results`, `artifacts`, `failures`, `flaky_analyses`, `change_proposals`, `pull_requests`, `agent_runs`, `ai_requests`, `audit_logs`, and `security_events`. Foreign keys retain provenance from every result to repository, branch, SHA and environment. Credentials and raw evidence values are deliberately absent.

## API contract families

* Repository: `GET /repositories`, `GET /repositories/:id/branches`, `POST /workspaces/checkout`, `GET /branches/:id/impact`.
* AI proposals: `POST /ai/test-design`, `/test-generation`, `/failure-analysis`, `/flaky-analysis`, `/test-healing`; all return validated proposal IDs and context-security summaries.
* Execution: `POST /executions`, `GET /executions/:id`, `GET /tests/:id/history`, `POST /credentials/runtime`.
* Change control: `GET /changes/:id/diff`, `POST /changes/:id/approve`, `POST /git/commit`, `POST /git/pull-request`.

Mutation responses include an audit ID; execution and AI endpoints require the repository context tuple.

## Frontend IA and design system

Primary navigation: Overview; AI QA (Designer, Generator, Failure Analysis, Healer); Tests (Explorer, Executions, Flaky, Impact); Repositories (Repositories, Branches, Code Intelligence); Insights; Integrations; Settings. The flagship guided flow binds repository → branch/SHA → environment → auth → requirement → reviewed scenarios → generated diff → approval → execution → evidence → healing proposal.

The system uses an ink/navy foundation, restrained cyan as action color, semantic status colors, dense readable tables, compact cards, 8px spacing rhythm, tabular metrics, keyboard-first command palette, responsive rail navigation, accessible contrast/focus styles, and light/dark tokens. Charts communicate derived/demo-labelled data only.

## Threat model and controls

Threats include malicious repositories, prompt injection in source/DOM, credential leakage, unsafe AI output, supply-chain scripts, artifact exposure, cross-workspace access, and protected-branch writes. Controls are worker isolation, egress/command policy, untrusted-context labelling, schema validation, approval gates, provider redaction, RBAC/tenant scoping, scoped tokens, encrypted artifacts, retention policies, immutable audit events, and rate limits. Production secrets require a vault before multi-user production deployment.

## MVP and phases

MVP: authenticated workspace shell, demo Bitbucket provider, branch/SHA context, repository profile viewer, requirement-to-scenario proposal, generated diff review, demo execution timeline, flakiness dashboard, security/context transparency, and approval/audit primitives.

Phase 2: repository indexing/retrieval, Azure provider, DOM semantic sanitizer, real scenario/test generation, patch application in worker.

Phase 3: container workers, Playwright result ingestion/artifacts, failure classification, historical flakiness and impact analysis.

Phase 4/5: healing verification, Bitbucket commits/PRs, RBAC, policy administration, observability, enterprise tenancy.

## Recommended stack and risks

Use Next.js + TypeScript + Tailwind + Radix/shadcn primitives; Fastify/NestJS or Next route handlers initially; PostgreSQL + Prisma/Drizzle; Redis/BullMQ; Azure OpenAI SDK; Playwright; Docker/Kubernetes jobs; OpenTelemetry; object storage. Key risks are executing hostile repositories, context/data leakage, unreliable AI code generation, broad Bitbucket permissions, and costly browser infrastructure. Resolve them with an isolated worker POC and sanitizer security review before enabling production execution.

## Development plan

1. Create UI shell, domain contracts, demo adapters, and audit/approval state.
2. Add database migrations, login/RBAC, and repository context APIs.
3. Build discovery/indexing and retrieved AI proposals with evaluation fixtures.
4. Prove isolated execution with a non-sensitive sample repository.
5. Integrate artifacts, intelligence metrics, healing and controlled Git writes.
