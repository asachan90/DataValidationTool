# Implementation status

Last updated: 2026-09-12

## Current completion level

This repository contains an **early Phase 3 implementation**, not a completed AI QA platform. The AI Test Designer and controlled demo execution flow call the local backend. It does not make live Bitbucket, database, Azure OpenAI, Playwright, Git, or container-worker calls.

## Completed

| Area | Status | What exists |
| --- | --- | --- |
| Product architecture | Complete for planning | System boundary, workers, security model, data model, API families, phases and risks in `architecture.md`. |
| Folder ownership | Complete | `frontend/` is a standalone Vite application; `backend/` is a standalone Python/FastAPI control plane. |
| Backend runtime | Complete | Python 3.12, FastAPI, Pydantic models, Uvicorn, and OpenAPI documentation. |
| Frontend runtime | Complete | React, TypeScript, Vite configuration and production build scripts. |
| Dashboard shell | Complete | Responsive navigation, branch context, execution-health graph, risk panel, recent executions, flaky-test watch, command menu. |
| Demo data | Complete | Clearly local, embedded UI sample data; not production logic. |
| Build verification | Complete | `npm run build` succeeds from `frontend/`. |
| Phase 2 API | Complete for local demo | Typed FastAPI/Pydantic API, repository profile endpoint, structured scenario and generated-diff endpoints. |
| Repository retrieval | Complete for local demo | Source documents are indexed in a demo adapter and ranked by query relevance with provenance hashes. |
| DOM sanitizer | Complete for local demo | Allowlisted semantic model, value/text exclusion, PII/secret detection, and fail-closed hidden/secret blocking. |
| AI review UI | Complete | Requirement input, API-backed scenarios, generated test diff, and context/security disclosure. |
| Controlled execution | Complete for demo | Queue lifecycle, demo-only allowlist policy, normalized test results, audit ID, and explicit no-shell/no-network/no-credential policy. |
| Failure intelligence | Complete for demo | Deterministic failure classification and redacted execution-log handling. |
| Flaky intelligence | Complete for demo | Historical-result aggregation, flakiness score, evidence, likely cause, and recommendation. |

## Designed, not yet implemented

| Area | Status | Next deliverable |
| --- | --- | --- |
| Control-plane API | Started | Replace in-memory demo adapters with validated persistence, authorization, and audit records. |
| PostgreSQL | Not started | Schema/migrations for repositories, commits, executions, results, proposals and audits. |
| Bitbucket | Demo boundary only | Add provider interface and OAuth production adapter. |
| Playwright discovery | Demo implementation | Parse a checked-out repository in the isolated worker. |
| Isolated execution | Execution boundary implemented | Add Docker/Kubernetes worker, resource quotas, sandbox filesystem, egress control, and teardown. Docker is not available in this development environment. |
| Azure OpenAI | Provider boundary | Enable transport only through an approved secret/managed-identity setup. |
| DOM protection | Not started | Semantic extractor, local PII/secret scanner and fail-closed policy. |
| Runtime credentials | Not started | One-time in-memory credential injection direct to worker. |
| Test generation/review | Not started | Requirement workflow, proposal/diff APIs and approval gate. |
| Failure/flaky intelligence | Demo implementation | Persist results/artifacts, ingest real Playwright reports, and run history analysis jobs. |
| Git/PR actions | Not started | Approval-bound commits and Bitbucket PR service. |
| Authentication/RBAC | Not started | Workspace membership, role policies and tenant scoping. |

## How to run the application

Start the Python API:

```powershell
cd backend
python -m pip install --user -r requirements.txt
python -m uvicorn app.main:app --reload --port 8787
```

Then start the frontend:

```powershell
cd frontend
npm install
npm run dev
```

For a production check:

```powershell
cd frontend
npm run build
```

## Recommended next increment

Add PostgreSQL-backed executions/results/artifacts and move the demo-only executor into an isolated Docker/Kubernetes worker. Then ingest Playwright JSON reports and trace/screenshot artifacts through the same normalized result contract.
