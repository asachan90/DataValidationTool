export type Context = { repositoryId: string; branchName: string; commitSha: string; environmentId: string };
export type Scenario = { id: string; title: string; priority: string; risk: string; preconditions: string[]; steps: string[]; expectedResults: string[] };
export type Proposal<T> = { id: string; provider: string; context: Context; contextUsed: { path: string; kind: string; reason: string; hash: string }[]; security: { elementsDiscovered: number; elementsSent: number; redacted: number; blocked: number; piiDetected: number; secretsDetected: number }; result: T };
export type Execution = { id: string; status: "QUEUED" | "RUNNING" | "COMPLETED" | "FAILED" | "REJECTED"; context: Context; results: { id: string; name: string; file: string; status: "PASSED" | "FAILED" | "FLAKY" | "SKIPPED"; durationMs: number; project: string; error?: string; logs: string[]; failureCategory?: string }[]; summary: { passed: number; failed: number; flaky: number; skipped: number; running: number }; policy: { mode: string; network: string; shell: string; credentials: string }; auditId: string };
export type Flaky = { testId: string; name: string; file: string; score: number; passRate: number; failureRate: number; likelyCause: string; evidence: string[]; recommendation: string };
const base = import.meta.env.VITE_API_URL ?? "http://localhost:8787";
async function request<T>(path: string, init?: RequestInit): Promise<T> { const response = await fetch(`${base}${path}`, { headers: { "content-type": "application/json" }, ...init }); const json = await response.json(); if (!response.ok) throw new Error(json.error ?? "Request failed"); return json; }
export const api = {
  profile: () => request<{ context: Context; profile: { playwrightVersion: string; projects: string[]; usesPageObjects: boolean; usesCustomFixtures: boolean; authentication: string }; indexedDocuments: { path: string; kind: string }[] }>("/api/repository-profile"),
  design: (requirement: string, context: Context) => request<Proposal<Scenario[]>>("/api/ai/test-design", { method: "POST", body: JSON.stringify({ requirement, context }) }),
  generate: (scenario: Scenario, context: Context) => request<Proposal<{ path: string; code: string; diff: string; dependencies: string[] }>>("/api/ai/test-generation", { method: "POST", body: JSON.stringify({ scenario, context }) }),
  run: (context: Context) => request<Execution>("/api/executions", { method: "POST", body: JSON.stringify({ context }) }),
  execution: (id: string) => request<Execution>(`/api/executions/${id}`),
  flaky: () => request<Flaky[]>("/api/flaky-tests"),
};
