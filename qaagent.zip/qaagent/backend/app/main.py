from __future__ import annotations

import asyncio
import hashlib
import re
from datetime import datetime, timezone
from typing import Any, Literal
from uuid import uuid4

from fastapi import FastAPI, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel, Field

app = FastAPI(title="TestFlair API", version="0.1.0")
app.add_middleware(CORSMiddleware, allow_origins=["http://localhost:5173"], allow_methods=["GET", "POST", "OPTIONS"], allow_headers=["content-type"])


class RepositoryContext(BaseModel):
    repositoryId: str
    branchName: str
    commitSha: str
    environmentId: str


class PageElement(BaseModel):
    element: str | None = None
    role: str | None = None
    label: str | None = None
    text: str | None = None
    value: str | None = None
    testId: str | None = None
    visible: bool | None = None
    hidden: bool | None = None
    attributes: dict[str, str] | None = None


class SanitizeRequest(BaseModel):
    elements: list[PageElement] = Field(default_factory=list)


class DesignRequest(BaseModel):
    requirement: str = Field(min_length=1, max_length=8000)
    context: RepositoryContext


class Scenario(BaseModel):
    id: str
    title: str
    priority: Literal["HIGH", "MEDIUM", "LOW"]
    risk: Literal["HIGH", "MEDIUM", "LOW"]
    preconditions: list[str]
    steps: list[str]
    expectedResults: list[str]


class GenerateRequest(BaseModel):
    scenario: Scenario
    context: RepositoryContext


class ExecutionRequest(BaseModel):
    context: RepositoryContext


DEMO_CONTEXT = RepositoryContext(repositoryId="customer-portal", branchName="feature/checkout-redesign", commitSha="a91f83c9b5e2", environmentId="qa")
DOCUMENTS = [
    {"path": "playwright.config.ts", "kind": "config", "content": "defineConfig({ testDir: './tests', retries: 2, projects: [{ name: 'chromium' }, { name: 'firefox' }] })"},
    {"path": "pages/CheckoutPage.ts", "kind": "page-object", "content": "class CheckoutPage { async open() {} async completeCheckout(order: TestOrder) {} async expectConfirmation() {} }"},
    {"path": "fixtures/auth.fixture.ts", "kind": "fixture", "content": "test.extend<{ authenticatedPage: Page }>({ authenticatedPage: async ({ page }, use) => use(page) })"},
    {"path": "tests/checkout.spec.ts", "kind": "test", "content": "test('should complete checkout', async ({ authenticatedPage, checkoutPage }) => checkoutPage.completeCheckout(testOrder))"},
    {"path": "utils/test-data.ts", "kind": "utility", "content": "export const createOrder = (overrides?: Partial<TestOrder>) => ({ sku: 'demo-sku', quantity: 1, ...overrides })"},
]
EXECUTIONS: dict[str, dict[str, Any]] = {}


def now() -> str:
    return datetime.now(timezone.utc).isoformat()


def security_summary(discovered: int = 0, sent: int = 0, redacted: int = 0, blocked: int = 0, pii: int = 0, secrets: int = 0) -> dict[str, Any]:
    return {"elementsDiscovered": discovered, "elementsSent": sent, "redacted": redacted, "blocked": blocked, "piiDetected": pii, "secretsDetected": secrets, "rawDomSent": False}


def retrieve(query: str) -> list[dict[str, str]]:
    query_words = set(re.findall(r"[a-z][a-z0-9-]{2,}", query.lower()))
    ranked = []
    for document in DOCUMENTS:
        words = set(re.findall(r"[a-z][a-z0-9-]{2,}", f"{document['path']} {document['content']}".lower()))
        ranked.append((len(query_words & words), document))
    return [{"path": item["path"], "kind": item["kind"], "reason": "Framework conventions" if item["kind"] == "config" else f"Relevant {item['kind'].replace('-', ' ')}", "hash": hashlib.sha256(item["content"].encode()).hexdigest()[:12]} for _, item in sorted(ranked, key=lambda value: value[0], reverse=True)[:5]]


def proposal(kind: str, context: RepositoryContext, result: Any, query: str) -> dict[str, Any]:
    return {"id": str(uuid4()), "kind": kind, "context": context.model_dump(), "provider": "demo", "createdAt": now(), "contextUsed": retrieve(query), "security": security_summary(), "result": result}


@app.get("/api/health")
def health() -> dict[str, str]:
    return {"status": "ok", "mode": "demo", "runtime": "python"}


@app.get("/api/repositories")
def repositories() -> list[dict[str, str]]:
    return [{"id": "customer-portal", "name": "customer-portal", "provider": "demo-bitbucket"}]


@app.get("/api/repositories/customer-portal/branches")
def branches() -> list[dict[str, str]]:
    return [{"name": DEMO_CONTEXT.branchName, "commitSha": DEMO_CONTEXT.commitSha}, {"name": "main", "commitSha": "d8c4a1f0aa21"}]


@app.get("/api/repository-profile")
def repository_profile() -> dict[str, Any]:
    return {"context": DEMO_CONTEXT.model_dump(), "profile": {"playwrightVersion": "1.51.x", "projects": ["chromium", "firefox"], "usesPageObjects": True, "usesCustomFixtures": True, "authentication": "authenticatedPage fixture", "testRoot": "./tests"}, "indexedDocuments": [{"path": item["path"], "kind": item["kind"]} for item in DOCUMENTS]}


@app.post("/api/security/sanitize")
def sanitize(request: SanitizeRequest) -> dict[str, Any]:
    pii_rules = [r"[A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,}", r"\b\d{3}[-.\s]?\d{2}[-.\s]?\d{4}\b", r"\b\d{3}[-.\s]?\d{3}[-.\s]?\d{4}\b"]
    secret_rule = r"(?:api[_-]?key|authorization|bearer|password|token|secret)[\s:=]+[^\s]+"
    clean, redacted, blocked, pii, secrets = [], 0, 0, 0, 0
    for item in request.elements:
        raw = item.model_dump_json()
        pii += sum(bool(re.search(rule, raw, re.I)) for rule in pii_rules)
        has_secret = bool(re.search(secret_rule, raw, re.I))
        secrets += int(has_secret)
        if item.hidden or has_secret:
            blocked += 1
            continue
        if item.value or item.text or item.attributes:
            redacted += 1
        clean.append({key: value for key, value in {"element": item.element, "role": item.role, "label": item.label, "testId": item.testId, "visible": item.visible}.items() if value is not None})
    return {"elements": clean, "summary": security_summary(len(request.elements), len(clean), redacted, blocked, pii, secrets)}


@app.post("/api/ai/test-design", status_code=201)
def test_design(request: DesignRequest) -> dict[str, Any]:
    subject = re.split(r"[.\n!]", request.requirement, maxsplit=1)[0].strip() or "the requested workflow"
    scenarios = [
        Scenario(id="scenario-valid", title=f"Complete {subject}", priority="HIGH", risk="HIGH", preconditions=["Authenticated customer", "A purchasable product exists"], steps=["Open the relevant workflow", "Provide valid required details", "Submit once"], expectedResults=["The operation completes", "A confirmation is displayed"]),
        Scenario(id="scenario-validation", title=f"Validate required fields for {subject}", priority="MEDIUM", risk="MEDIUM", preconditions=["Authenticated customer"], steps=["Open the workflow", "Leave a required field empty", "Submit"], expectedResults=["Inline validation is visible", "No operation is created"]),
        Scenario(id="scenario-duplicate", title=f"Prevent duplicate submission for {subject}", priority="MEDIUM", risk="HIGH", preconditions=["Authenticated customer", "Valid test data"], steps=["Complete required details", "Submit twice while pending"], expectedResults=["Only one operation is created", "Submit is idempotent"]),
    ]
    return proposal("test-design", request.context, [scenario.model_dump() for scenario in scenarios], request.requirement)


@app.post("/api/ai/test-generation", status_code=201)
def test_generation(request: GenerateRequest) -> dict[str, Any]:
    code = f"import {{ test }} from '../fixtures/auth.fixture';\nimport {{ createOrder }} from '../utils/test-data';\n\ntest('{request.scenario.title.lower()}', async ({{ authenticatedPage, checkoutPage }}) => {{\n  const order = createOrder();\n  await checkoutPage.open();\n  await checkoutPage.completeCheckout(order);\n  await checkoutPage.expectConfirmation();\n}});\n"
    return proposal("test-generation", request.context, {"path": "tests/generated/checkout-ai.spec.ts", "code": code, "diff": "+++ tests/generated/checkout-ai.spec.ts\n" + "\n".join(f"+{line}" for line in code.splitlines()), "dependencies": ["fixtures/auth.fixture.ts", "pages/CheckoutPage.ts", "utils/test-data.ts"]}, request.scenario.title)


def summarize(results: list[dict[str, Any]], status: str) -> dict[str, int]:
    return {"passed": sum(result["status"] == "PASSED" for result in results), "failed": sum(result["status"] == "FAILED" for result in results), "flaky": sum(result["status"] == "FLAKY" for result in results), "skipped": sum(result["status"] == "SKIPPED" for result in results), "running": int(status == "RUNNING")}


async def run_demo(execution_id: str) -> None:
    await asyncio.sleep(.25)
    execution = EXECUTIONS[execution_id]; execution["status"] = "RUNNING"; execution["startedAt"] = now(); execution["summary"] = summarize([], "RUNNING")
    await asyncio.sleep(.65)
    results = [
        {"id": "checkout-happy", "name": "should complete checkout", "file": "tests/checkout.spec.ts", "status": "PASSED", "durationMs": 4821, "project": "chromium", "logs": ["Navigated to /checkout", "Order confirmation visible"]},
        {"id": "order-history", "name": "preserves saved address", "file": "tests/profile.spec.ts", "status": "FLAKY", "durationMs": 8312, "project": "chromium", "error": "Timeout waiting for address list after retry", "logs": ["Retry 1 of 2", "timeout waiting for address-list"], "failureCategory": "FLAKY_TEST"},
        {"id": "payment-method", "name": "updates payment method", "file": "tests/billing.spec.ts", "status": "FAILED", "durationMs": 6120, "project": "firefox", "error": "Expected confirmation banner, received HTTP 502 from payment gateway", "logs": ["POST /api/payment-method → 502", "Screenshot withheld: evidence policy demo"], "failureCategory": "NETWORK_ISSUE"},
    ]
    execution["results"] = results; execution["status"] = "COMPLETED"; execution["completedAt"] = now(); execution["summary"] = summarize(results, "COMPLETED")


@app.post("/api/executions", status_code=202)
async def create_execution(request: ExecutionRequest) -> dict[str, Any]:
    if request.context.repositoryId != "customer-portal":
        raise HTTPException(403, "Execution policy rejects repositories outside the demo allowlist.")
    execution_id = str(uuid4())
    execution = {"id": execution_id, "context": request.context.model_dump(), "status": "QUEUED", "createdAt": now(), "policy": {"mode": "demo-only", "network": "blocked", "shell": "not-available", "credentials": "not-accepted"}, "results": [], "summary": summarize([], "QUEUED"), "auditId": str(uuid4())}
    EXECUTIONS[execution_id] = execution
    asyncio.create_task(run_demo(execution_id))
    return execution


@app.get("/api/executions")
def list_executions() -> list[dict[str, Any]]:
    return sorted(EXECUTIONS.values(), key=lambda item: item["createdAt"], reverse=True)


@app.get("/api/executions/{execution_id}")
def get_execution(execution_id: str) -> dict[str, Any]:
    if execution_id not in EXECUTIONS:
        raise HTTPException(404, "Execution not found")
    return EXECUTIONS[execution_id]


@app.get("/api/flaky-tests")
def flaky_tests() -> list[dict[str, Any]]:
    history = [result for execution in EXECUTIONS.values() for result in execution["results"] if result["status"] == "FLAKY"]
    return [{"testId": item["id"], "name": item["name"], "file": item["file"], "score": 76, "passRate": 0, "failureRate": 100, "averageDurationMs": item["durationMs"], "durationVarianceMs": 0, "recentFailureRate": 100, "likelyCause": "Race condition / asynchronous UI", "evidence": ["Retry-sensitive timeout on address-list", "Unstable result in recent execution history"], "recommendation": "Replace fixed timing with a visible-state assertion and isolate address test data."} for item in history]
