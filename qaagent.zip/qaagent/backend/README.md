# TestFlair backend

The backend is a Python 3.12 + FastAPI control-plane foundation. It provides the local demo repository, semantic DOM sanitization, AI test design/generation proposals, controlled execution lifecycle, failure categories, and flaky-test analysis.

It deliberately has no database, live credentials, external Bitbucket calls, Azure transport, or arbitrary shell execution. The demo worker accepts only `customer-portal`, blocks network/shell/credentials, and returns normalized example results.

Run it:

```powershell
cd backend
python -m pip install --user -r requirements.txt
python -m uvicorn app.main:app --reload --port 8787
```

OpenAPI documentation is available at `http://127.0.0.1:8787/docs`.
