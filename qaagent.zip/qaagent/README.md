# TestFlair

AI-assisted, branch-aware Playwright QA engineering platform — currently in its frontend-foundation stage.

```text
frontend/   Vite + React + TypeScript application
backend/    Python + FastAPI control-plane API
docs/       Architecture, original product brief, and progress tracking
```

Run the UI with `cd frontend; npm install; npm run dev` and the API with `cd backend; python -m uvicorn app.main:app --reload --port 8787`.

Read [the architecture](docs/architecture.md), [the original product brief](docs/original-product-prompt.md), and [the implementation status](docs/implementation-status.md).
